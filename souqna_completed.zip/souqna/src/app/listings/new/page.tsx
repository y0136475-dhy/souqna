import NewListingForm from './NewListingForm';
export const metadata = { title: 'إضافة إعلان' };
export default function NewListingPage(){return <div className="container max-w-3xl py-8"><span className="badge">للبائعين ومقدمي الخدمات</span><h1 className="mt-3 text-3xl font-extrabold">أضف إعلانك</h1><p className="mb-6 mt-2 text-slate-500">أكمل التفاصيل بدقة. سيخضع الإعلان للمراجعة قبل نشره.</p><NewListingForm/></div>}
