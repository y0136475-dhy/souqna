import Link from 'next/link';
import { notFound } from 'next/navigation';
import { isSupabaseConfigured, SECTIONS, supabase } from '@/lib/supabase';
export const dynamic = 'force-dynamic';

export default async function ListingDetail({params,searchParams}:{params:Promise<{id:string}>;searchParams:Promise<{created?:string}>}) {
  const {id}=await params; const {created}=await searchParams;
  if(!isSupabaseConfigured||!supabase) return <div className="container py-12"><div className="card p-8 text-center"><h1 className="text-2xl font-extrabold">تفاصيل الإعلان</h1><p className="mt-3 text-slate-500">اربط قاعدة بيانات Supabase لعرض الإعلانات الحقيقية.</p><Link href="/search" className="btn btn-primary mt-5">العودة إلى البحث</Link></div></div>;
  const {data,error}=await supabase.from('listings').select('id,title,description,price,section,wilaya_id,status,created_at,wilayas(name)').eq('id',id).maybeSingle();
  if(error||!data) notFound();
  const {data:wilaya}=await supabase.from('wilayas').select('name').eq('id',data.wilaya_id).maybeSingle();
  return <div className="container max-w-3xl py-8">
    {created==='1'&&<div className="mb-4 rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-900">تم إرسال إعلانك بنجاح، وهو الآن قيد المراجعة. يمكنك متابعة حالته من لوحة التحكم.</div>}
    <Link href="/search" className="text-sm font-bold text-teal-700">← العودة إلى الإعلانات</Link>
    <article className="card mt-4 overflow-hidden"><div className="bg-gradient-to-bl from-emerald-50 to-amber-50 p-8 sm:p-12"><span className="badge">{SECTIONS[data.section]||'إعلان'}</span><h1 className="mt-4 text-3xl font-extrabold leading-snug">{data.title}</h1><p className="mt-4 text-2xl font-extrabold text-teal-700">{data.price==null?'السعر عند التواصل':`${Number(data.price).toLocaleString('ar-DZ')} دج`}</p><p className="mt-2 text-sm text-slate-500">📍 {wilaya?.name||'الجزائر'} · {new Date(data.created_at).toLocaleDateString('ar-DZ')}</p></div>
      <div className="p-6 sm:p-8"><h2 className="text-lg font-extrabold">وصف الإعلان</h2><p className="mt-3 whitespace-pre-wrap leading-8 text-slate-700">{data.description||'لم يضف صاحب الإعلان وصفًا إضافيًا.'}</p>{data.status!=='active'&&<p className="mt-5 rounded-xl bg-amber-50 p-3 text-sm text-amber-900">هذا الإعلان غير منشور للعامة بعد.</p>}<div className="mt-7 rounded-xl bg-slate-50 p-4"><p className="font-bold">مهتم بهذا الإعلان؟</p><p className="mt-1 text-sm text-slate-500">تسجيل الدخول والتواصل المباشر سيُفعّلان بعد استكمال نظام الرسائل وحماية بيانات التواصل.</p><Link href="/auth" className="btn btn-primary mt-3">تسجيل الدخول</Link></div></div>
    </article>
  </div>;
}
