import AuthForm from './AuthForm';
export const metadata = { title: 'تسجيل الدخول' };
export default function AuthPage() {
  return <div className="container py-10 sm:py-16"><AuthForm/></div>;
}
