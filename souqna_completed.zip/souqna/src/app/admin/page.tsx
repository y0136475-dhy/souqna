import AdminClient from './AdminClient';
export const metadata = { title: 'إدارة المنصة' };
export default function AdminPage(){return <AdminClient/>}
