import DashboardClient from './DashboardClient';
export const metadata = { title: 'لوحة التحكم' };
export default function DashboardPage(){return <DashboardClient/>}
