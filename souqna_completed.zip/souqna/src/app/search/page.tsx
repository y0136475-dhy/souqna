import Link from 'next/link';
import { isSupabaseConfigured, SECTIONS, WILAYAS, supabase } from '@/lib/supabase';

type SP = { q?: string; section?: string; wilaya?: string; max?: string };
export const dynamic = 'force-dynamic';
export const metadata = { title: 'تصفّح الإعلانات' };

export default async function SearchPage({ searchParams }: { searchParams: Promise<SP> }) {
  const { q = '', section = '', wilaya = '', max = '' } = await searchParams;
  let data: any[] = [];
  let loadError = '';
  if (!isSupabaseConfigured || !supabase) loadError = 'يلزم إعداد قاعدة البيانات قبل عرض الإعلانات الحقيقية.';
  else {
    let query = supabase.from('listings').select('id,title,description,price,section,wilaya_id,created_at,wilayas(name)').eq('status','active').order('created_at',{ascending:false}).limit(60);
    if (q.trim()) query = query.ilike('title', `%${q.trim().replace(/[%,]/g,'')}%`);
    if (Object.prototype.hasOwnProperty.call(SECTIONS, section)) query = query.eq('section',section);
    if (wilaya && /^\d+$/.test(wilaya)) query = query.eq('wilaya_id',Number(wilaya));
    if (max && /^\d+$/.test(max)) query = query.lte('price',Number(max));
    const result = await query;
    if (result.error) loadError = 'تعذّر تحميل الإعلانات. تحقق من إعداد Supabase وتشغيل ملف قاعدة البيانات.';
    else data = result.data ?? [];
  }
  return <div className="container py-8">
    <div className="mb-6"><span className="badge">اكتشف سوقنا</span><h1 className="mt-3 text-3xl font-extrabold">تصفّح الإعلانات</h1><p className="mt-2 text-slate-500">ابحث حسب الكلمات والقسم والولاية والسعر.</p></div>
    <form className="card mb-6 grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-5">
      <div className="field lg:col-span-2"><label htmlFor="q">كلمات البحث</label><input id="q" name="q" defaultValue={q} placeholder="ما الذي تبحث عنه؟"/></div>
      <div className="field"><label htmlFor="section">القسم</label><select id="section" name="section" defaultValue={section}><option value="">كل الأقسام</option>{Object.entries(SECTIONS).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></div>
      <div className="field"><label htmlFor="wilaya">الولاية</label><select id="wilaya" name="wilaya" defaultValue={wilaya}><option value="">كل الولايات</option>{WILAYAS.map((v,i)=><option key={v} value={i+1}>{v}</option>)}</select></div>
      <div className="field"><label htmlFor="max">أقصى سعر (دج)</label><input id="max" name="max" inputMode="numeric" defaultValue={max} placeholder="مثال: 50000"/></div>
      <div className="sm:col-span-2 lg:col-span-5"><button className="btn btn-primary w-full sm:w-auto">تطبيق البحث</button><Link href="/search" className="btn btn-secondary mr-2">مسح الفلاتر</Link></div>
    </form>
    {loadError && <div className="mb-5 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900"><strong>إعداد مطلوب:</strong> {loadError} <p className="mt-1">راجع ملف README لمعرفة خطوات الربط. لن تظهر بيانات وهمية على أنها إعلانات حقيقية.</p></div>}
    <div className="mb-4 flex items-center justify-between"><h2 className="font-bold">النتائج</h2><span className="text-sm text-slate-500">{data.length} إعلان</span></div>
    {data.length ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{data.map((item:any)=><Link key={item.id} href={`/listings/${item.id}`} className="card block p-5 transition hover:-translate-y-1 hover:border-teal-300"><span className="badge">{SECTIONS[item.section] ?? 'إعلان'}</span><h3 className="mt-3 text-lg font-extrabold">{item.title}</h3><p className="mt-2 line-clamp-3 min-h-12 text-sm text-slate-500">{item.description || 'لا يوجد وصف إضافي.'}</p><div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3"><strong className="text-teal-700">{item.price == null ? 'السعر عند التواصل' : `${Number(item.price).toLocaleString('ar-DZ')} دج`}</strong><span className="text-xs text-slate-500">📍 {item.wilayas?.name ?? 'الجزائر'}</span></div></Link>)}</div> : <div className="card py-14 text-center"><div className="text-4xl">🔎</div><h3 className="mt-3 font-bold">لا توجد إعلانات لعرضها</h3><p className="mt-2 text-sm text-slate-500">{loadError ? 'أكمل إعداد قاعدة البيانات أولًا.' : 'جرّب تغيير كلمات البحث أو أضف أول إعلان بعد تسجيل الدخول.'}</p><Link href="/listings/new" className="btn btn-primary mt-5">أضف إعلانًا</Link></div>}
  </div>;
}
